INSERT INTO `autogendb`.`locator_by`
(`by_id`,
`by_name`)
VALUES
(0,"ClassName"),
(1,"XPath"),
(2,"Id"),
(3,"Name"),
(4,"LinkText"),
(5,"PartialLinkText"),
(6,"CssSelector")