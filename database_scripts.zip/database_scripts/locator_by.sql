CREATE TABLE `autogendb`.`locator_by` (
  `by_id` INT NOT NULL,
  `by_name` VARCHAR(45) NOT NULL);
